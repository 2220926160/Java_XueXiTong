package cn.zfz;

public class Driver {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.systemMenu();
    }
}
