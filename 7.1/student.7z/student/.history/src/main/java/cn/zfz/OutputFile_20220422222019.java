package cn.zfz;
public class OutputFile {
    public boolean outputExcel() {
        return false
    }
}
