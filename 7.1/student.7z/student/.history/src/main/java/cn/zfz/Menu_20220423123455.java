package cn.zfz;

import java.util.Scanner;

public class Menu {
    public Scanner sc = new Scanner(System.in);
    // 登录界面
    public void loginMenu() {

    }
    // 系统界面
    public void systemMenu() {
        while (true) {
            System.out.println(" ======学生成绩管理系统======= ");
        }
    }
}
