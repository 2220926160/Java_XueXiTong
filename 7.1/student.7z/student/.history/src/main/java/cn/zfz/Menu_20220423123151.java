package cn.zfz;
public class Menu {
    public void loginMenu() {

    }
}
