package cn.zfz;

import java.util.Scanner;

public class Menu {
    public Scanner sc = new Scanner(System.in);
    public void loginMenu() {

    }

    public void systemMenu() {

    }
}
