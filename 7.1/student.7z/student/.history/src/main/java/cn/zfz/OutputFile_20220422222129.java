package cn.zfz;

import java.util.ArrayList;

public class OutputFile {
    // 输出到 excel 文件
    public boolean outputExcel(ArrayList<StudentInfo> studentList) {
        return false;
    }
    // 输出到 txt 文件
    public boolean outputTxt(ArrayList<StudentInfo> studentList) {
        return false;
    }
}
