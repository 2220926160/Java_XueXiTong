package cn.zfz;
public class Menu {
    public void loginMenu() {

    }

    public void systemMenu() {
        
    }
}
