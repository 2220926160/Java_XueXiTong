package cn.zfz;

import java.util.ArrayList;

import jxl.*;

public class InputFile {
    // 从 excel 中加载数据
    public ArrayList<StudentInfo> InputExcel() {
        ArrayList<StudentInfo> studentList = new ArrayList<StudentInfo>();
        return studentList;
    }
    // 从 txt 中加载数据
    public ArrayList<StudentInfo> InputTxt() {
        ArrayList<StudentInfo> studentList = new ArrayList<StudentInfo>();
        return studentList;
    }
    // 从 xml 中加载数据
    public ArrayList<StudentInfo> InputXml() {
        ArrayList<StudentInfo> studentList = new ArrayList<StudentInfo>();
        return studentList;
    }
    // 从 json 中加载数据
    public ArrayList<StudentInfo> InputJson() {
        ArrayList<StudentInfo> studentList = new ArrayList<StudentInfo>();
        return studentList;
    }
}
