package cn.zfz;

import java.util.ArrayList;

public class LoadFile {
    // 从 excel 中加载数据
    public ArrayList<StudentInfo> loadExcel() {
        ArrayList<StudentInfo> studentList = new ArrayList<StudentInfo>();
        return studentList;
    }
    // 从 txt 中加载数据
    public ArrayList<StudentInfo> loadTxt() {
        ArrayList<StudentInfo> studentList = new ArrayList<StudentInfo>();
        return studentList;
    }
    // 从 xml 中加载数据
    public ArrayList<StudentInfo> loadXml() {
        ArrayList<StudentInfo> studentList = new ArrayList<StudentInfo>();
        return studentList;
    }
    // 从 json 中加载数据
    public ArrayList<StudentInfo> loadJson() {
        ArrayList<StudentInfo> studentList = new ArrayList<StudentInfo>();
        return studentList;
    }
}
