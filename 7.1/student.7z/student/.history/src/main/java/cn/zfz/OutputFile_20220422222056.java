package cn.zfz;

import java.util.ArrayList;

public class OutputFile {
    public boolean outputExcel(ArrayList<StudentInfo> studentList) {
        return false;
    }
}
